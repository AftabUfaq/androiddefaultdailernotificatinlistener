 
package com.lesimoes.androidnotificationlistener;
import android.content.Intent;
import android.content.Context;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.app.Notification;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.facebook.react.HeadlessJsTaskService;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.WritableMap;

import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

@RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
public class RNAndroidNotificationListener extends NotificationListenerService {
    private static final String TAG = "NotificationListener";
    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        Notification notification = sbn.getNotification();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            if (notification == null || notification.extras == null) return;
        }

        String app = sbn.getPackageName();
        boolean isDefault = isDefaultDialer(getApplicationContext(),app);

        if (app == null) app = "Unknown";

        CharSequence titleChars = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
            titleChars = notification.extras.getCharSequence(Notification.EXTRA_TITLE);
        }

        CharSequence textChars = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
            textChars = notification.extras.getCharSequence(Notification.EXTRA_TEXT);
        }

        if (titleChars == null || textChars == null) return;
        
        String title = titleChars.toString();
        String text = textChars.toString();

        if (text == null || "".equals(text) || title == null || "".equals(title)) return;

        if(isDefault) {
            String current_incomming_number = titleChars.toString();  // mobile number
            String current_incomming_number_type = textChars.toString();  // call type
            sendNotifcation(app, current_incomming_number, current_incomming_number_type);
        }
        else{
            return;
        }

    }
    public void sendNotifcation (String app , String title , String text ) {
        Intent serviceIntent = new Intent(getApplicationContext(), RNAndroidNotificationListenerHeadlessJsTaskService.class);
        serviceIntent.putExtra("app", app);
        serviceIntent.putExtra("title", title);
        serviceIntent.putExtra("text", text);
        HeadlessJsTaskService.acquireWakeLockNow(getApplicationContext());
        getApplicationContext().startService(serviceIntent);
        WritableMap params = Arguments.createMap();
        params.putString("app", app);
        params.putString("title", title);
        params.putString("text", text);
        //  Log.e(TAG, "Notification if condition 3  same number: " + app + " | " + current_incomming_number + " | " + current_incomming_number_type);
        RNAndroidNotificationListenerModule.sendEvent("notificationReceived", params);
    }

    public boolean isDefaultDialer(Context context, String packageNameToCheck) {
        Intent dialingIntent = new Intent(Intent.ACTION_DIAL).addCategory(Intent.CATEGORY_DEFAULT);
        List<ResolveInfo> resolveInfoList = context.getPackageManager().queryIntentActivities(dialingIntent, 0);
        if (resolveInfoList.size() < 1)
            return false;
        else
        {
            if(packageNameToCheck.contains("incallui")) return true;
            for (ResolveInfo item : resolveInfoList)
            {
                if(packageNameToCheck.equals(item.activityInfo.packageName))
                {
                    return true;
                }
            }
        }
        return packageNameToCheck == resolveInfoList.get(0).activityInfo.packageName;
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {}
}