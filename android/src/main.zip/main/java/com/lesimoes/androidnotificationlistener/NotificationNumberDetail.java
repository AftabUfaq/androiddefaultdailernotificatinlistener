package com.lesimoes.androidnotificationlistener;


public class NotificationNumberDetail {
    private String incomingNmbr="";
    private String incomingType="";
    private boolean identifiable=false;
    public NotificationNumberDetail()
    {

    }
    public NotificationNumberDetail(String incomingNmbr,String incomingType,boolean identifiable)
    {
        this.incomingNmbr=incomingNmbr;
        this.incomingType=incomingType;
        this.identifiable=identifiable;
    }
    public String getIncomingNmbr() {
        return incomingNmbr;
    }

    public void setIncomingNmbr(String incomingNmbr) {
        this.incomingNmbr = incomingNmbr;
    }

    public String getIncomingType() {
        return incomingType;
    }

    public void setIncomingType(String incomingType) {
        this.incomingType = incomingType;
    }

    public boolean isIdentifiable() {
        return identifiable;
    }

    public void setIdentifiable(boolean identifiable) {
        this.identifiable = identifiable;
    }
}
